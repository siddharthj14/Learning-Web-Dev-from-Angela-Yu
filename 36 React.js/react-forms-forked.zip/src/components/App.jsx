import React, { useState } from "react";

function App() {
  const [name, setName] = useState("");
  const [displayName, setDisplayName] = useState(false);

  function handleChange(event) {
    setName(event.target.value);
    if (event.target.value.length == 0) {
      setDisplayName(false);
    }
  }

  function handleClick() {
    setDisplayName(true);
  }
  return (
    <div className="container">
      <h1>Hello {displayName && name}</h1>
      {console.log(name)}
      <input
        onChange={handleChange}
        type="text"
        placeholder="What's your name?"
      />
      <button onClick={handleClick}>Submit</button>
    </div>
  );
}

export default App;
