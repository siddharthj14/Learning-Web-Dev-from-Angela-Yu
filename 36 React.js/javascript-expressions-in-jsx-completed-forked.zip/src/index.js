import React from "react";
import ReactDOM from "react-dom";

const fName = "Siddharth";
const lName = "Jain";
const num = 4;

ReactDOM.render(
  <div>
    <h1>Hello {fName + " " + lName}!</h1>
    <p>Your lucky number is {num}</p>
  </div>,
  document.getElementById("root")
);
