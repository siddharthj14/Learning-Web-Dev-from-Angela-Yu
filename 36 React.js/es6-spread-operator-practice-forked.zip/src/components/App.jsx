import React, { useState } from "react";

function App() {
  const [inputValue, setInputValue] = useState("");
  const [itemArray, setItemArray] = useState([]);

  function handleAdd() {
    setItemArray((prevValue) => [...prevValue, inputValue]);
    setInputValue("");
  }

  function handleChange(event) {
    setInputValue(event.target.value);
  }

  return (
    <div className="container">
      <div className="heading">
        <h1>To-Do List</h1>
      </div>
      <div className="form">
        <input type="text" value={inputValue} onChange={handleChange} />
        <button onClick={handleAdd}>
          <span>Add</span>
        </button>
      </div>
      <div>
        <ul>
          {itemArray &&
            itemArray.map((item, index) => <li key={index}>{item}</li>)}
        </ul>
      </div>
    </div>
  );
}

export default App;
