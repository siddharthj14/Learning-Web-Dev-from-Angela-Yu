import React from "react";

const d = new Date();
let time = d.getHours();

const customStyle = {
  color: "red",
};

function greeting() {
  if (time <= 12) {
    return "Good Morning";
  } else if (time <= 18) {
    customStyle.color = "green";
    return "Good Afternoon";
  } else {
    customStyle.color = "blue";
    return "Good Evening";
  }
}

function Heading() {
  return (
    <div>
      <h1 className="heading" style={customStyle}>
        {greeting()}
      </h1>
      ,
    </div>
  );
}

export default Heading;
