import React from "react";
import ReactDOM from "react-dom";

ReactDOM.render(
  <div>
    <h1 className="heading">My Favourite Foods</h1>
    <ul>
      <img
        src="https://thumbs.dreamstime.com/b/chole-bhature-spicy-chick-peas-curry-also-known-as-channa-masala-traditional-north-indian-main-course-recipe-usually-223997690.jpg"
        alt="Chhole bhature"
      />
      <img
        src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT-jMJJUa4Ur-sN5yx1D4qrerKc_B-3rJouow&usqp=CAU"
        alt="Pav Bhaji"
      />
      <img
        src="https://www.secondrecipe.com/wp-content/uploads/2020/11/dal-bati-churma.jpg"
        alt="Dal Bati"
      />
    </ul>
  </div>,
  document.getElementById("root")
);
