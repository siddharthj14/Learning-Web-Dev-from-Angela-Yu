import React, { useState } from "react";

function App() {
  const [fName, setFName] = useState("");
  const [lName, setLName] = useState("");
  const [fullName, setFullName] = useState("");

  function handleFChange(event) {
    setFName(event.target.value);
  }
  function handleLChange(event) {
    setLName(event.target.value);
  }

  function handleSubmit(event) {
    setFullName(fName + " " + lName);
    event.preventDefault();
  }
  return (
    <div className="container">
      <h1>Hello {fullName}</h1>
      <form onSubmit={handleSubmit}>
        <input onChange={handleFChange} name="fName" placeholder="First Name" />
        <input onChange={handleLChange} name="lName" placeholder="Last Name" />
        <button>Submit</button>
      </form>
    </div>
  );
}

export default App;
